# CodeClause_FeeReport
A simple Fee Report Managment System project which uses VS Code IDE and concepts like AWT, Swing, MySQL and JDBC. Language used is Core Java. To see the explanitory video of the project visit https://www.linkedin.com/in/neha-gawali-0a8a06205
Technical minds youtube video is used as a reference for this project and code is wrriten in own language with some updates by the me like add back buttons to each page,images etc. Here the link of reference video by technical minds https://www.youtube.com/watch?v=t6u2QqzCVP8&list=PLSelijxfOX7pfbCcHoyAH6U7p6EIMxj4g.
